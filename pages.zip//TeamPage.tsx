import { Team } from "../components/Team";

export function TeamPage() {
  return (
    <div className="pt-16">
      <Team />
    </div>
  );
}
