import { CTA } from "../components/CTA";

export function ContactPage() {
  return (
    <div className="pt-16">
      <CTA />
    </div>
  );
}
