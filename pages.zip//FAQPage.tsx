import { FAQ } from "../components/FAQ";

export function FAQPage() {
  return (
    <div className="pt-16">
      <FAQ />
    </div>
  );
}
