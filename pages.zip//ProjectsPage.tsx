import { Projects } from "../components/Projects";

export function ProjectsPage() {
  return (
    <div className="pt-16">
      <Projects />
    </div>
  );
}
